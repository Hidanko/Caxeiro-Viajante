package ag.cv;

import java.awt.*;
import javax.swing.*;
public class Painel extends JPanel{
	
	public static JFrame janela = new JFrame("Algorítmos Genéticos - Daniel Oliveira e Gustavo Pereira");
	public static Painel painel = null;
	public static Caminho melhorCaminho;
	public static Caminho ultimoCaminho;
	public static int geracao;
	
	
	public Painel(){};
	public Painel(Caminho melhor){
		ultimoCaminho = melhorCaminho;
		melhorCaminho = melhor;
	}

	public static void criarJanela(){
	
            janela.setLocationRelativeTo(null);
	     janela.setVisible(true);
	     janela.setSize(600, 70);
	}
	public static void atualizarJanela(Caminho best){
		if(melhorCaminho != null && melhorCaminho.equals(best)){
			return;
		}
		if(painel != null){
			janela.remove(painel);
		}
		Painel g = new Painel(best);
		janela.add(g);
		janela.setVisible(true);
	}
	
	public static void setGeracao(int geracaoAtual){
		geracao = geracaoAtual;
	}
	
        @Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		this.setBackground(Color.WHITE);
		g.setFont(g.getFont().deriveFont(20.0f));
		g.setColor(Color.RED);
		g.drawString("Geração: "+geracao, 230, 20);
		g.setColor(Color.BLACK);
		g.drawString("Mutações: "+AG.getMutações(), 390, 20);
		g.setColor(Color.BLUE);
		g.drawString("Comprimento: "+(int)melhorCaminho.getDistancia(), 10, 20);
//		Cidade city, city2;
//		for(int i = 0; i < melhorCaminho.tamanhoDoCaminho(); i++){
//        	city = melhorCaminho.getCidade(i);
//        	if(i+1 < melhorCaminho.tamanhoDoCaminho()){
//        		city2 = melhorCaminho.getCidade(i+1);
//        	}else{
//        		city2 = melhorCaminho.getCidade(0);
//        	}
//        	//g.setColor(Color.BLUE);
//                g.fillRect(city.getX()*6-5,city.getY()*6-5,10,10);
//        	g.setColor(Color.RED);
//        	//g.drawString(city.getName(), city.getX()*6-5, city.getY()*6-10);
//        	//g.drawLine(city.getX()*6-5,city.getY()*6-5, city2.getX()*6-5,city2.getY()*6-5);
//        	
//        }
		
	}

}