package ag.cv;

import java.util.ArrayList;
/*
 * Classe que guarda todas as cidades destino de uma rota (caminho)
 * */
public class CaminhoManager {
	//Uma lista que contém todas as cidades que o caixeiro tera de visitar
    private static final ArrayList<Cidade> cidadesNaoPercorridas = new ArrayList<>();

    //Adiciona uma cidade na lista de cidades a serem visitadas
    public static void addCidade(Cidade cidade) {
        cidadesNaoPercorridas.add(cidade);
    }
    
    //Retorna a cidade que se encontra na posição 'indice' da lista de cidades
    public static Cidade getCidade(int indice){
        return cidadesNaoPercorridas.get(indice);
    }
    
    //Retorna o número de cidades da lista
    public static int numeroDeCidades(){
        return cidadesNaoPercorridas.size();
    }
}
