package ag.cv;

public class Populacao {
    Caminho[] caminhos;

    //Construtor de uma população
    public Populacao(int tamanhoDaPopulacao, boolean inicializar) {
        caminhos = new Caminho[tamanhoDaPopulacao];
        if (inicializar) {
            // Criação dos individuos da geração
            for (int i = 0; i < tamanhoDaPopulacao(); i++) {
                Caminho novoCaminho = new Caminho();
                novoCaminho.geracaoIndividual();
                salvarCaminho(i, novoCaminho);
            }
        }
    }
    
    //Salva um caminho
    public void salvarCaminho(int indice, Caminho caminho) {
        caminhos[indice] = caminho;
    }
    
    //Pega um individuo da população
    public Caminho getCaminho(int indice) {
        return caminhos[indice];
    }

    //Pega o melhor individuo (caminho) da população
    public Caminho getFittest() {
        Caminho fittest = getCaminho(0);
        for(int i = 1; i < tamanhoDaPopulacao(); i++) {
            if(fittest.getFitness() <= getCaminho(i).getFitness()) {
                fittest = getCaminho(i);
            }
        }
        return fittest;
    }

    //Pega o tamanho da população
    public int tamanhoDaPopulacao() {
    	return caminhos.length;
    }
}
