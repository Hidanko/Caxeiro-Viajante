/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ag.cv;

import javax.swing.JOptionPane;

/**
 *
 * @author gustavo
 */
public class AGCV {

    /**
     */
    //public static boolean preenchido=false;
    public static void main(String[] args) throws InterruptedException {
        //Painel.criarJanela();
        IniciaVariaveis in = new IniciaVariaveis();
        in.setVisible(true);
        while (!in.preenchido) {
            Thread.sleep(500);
        }
        try {

        Painel.criarJanela();
            
        Cidade city = new Cidade("Lisboa", 60, 200);
        CaminhoManager.addCidade(city);
        Cidade city2 = new Cidade("Santar�m", 180, 200);
        CaminhoManager.addCidade(city2);
        Cidade city3 = new Cidade("Braga", 80, 180);
        CaminhoManager.addCidade(city3);
        Cidade city4 = new Cidade("Bragan�a", 140, 180);
        CaminhoManager.addCidade(city4);
        Cidade city5 = new Cidade("Porto", 20, 160);
        CaminhoManager.addCidade(city5);
        Cidade city6 = new Cidade("Portalegre", 100, 160);
        CaminhoManager.addCidade(city6);
        Cidade city7 = new Cidade("Viseu", 200, 160);
        CaminhoManager.addCidade(city7);
        Cidade city8 = new Cidade("Set�bal", 140, 140);
        CaminhoManager.addCidade(city8);
        Cidade city9 = new Cidade("Samora", 40, 120);
        CaminhoManager.addCidade(city9);
        Cidade city10 = new Cidade("Beja", 100, 120);
        CaminhoManager.addCidade(city10);
        Cidade city11 = new Cidade("Aveiro", 180, 100);
        CaminhoManager.addCidade(city11);
        Cidade city12 = new Cidade("Barcelos", 60, 80);
        CaminhoManager.addCidade(city12);
        Cidade city13 = new Cidade("Faro", 120, 80);
        CaminhoManager.addCidade(city13);
        Cidade city14 = new Cidade("Guimar�es", 180, 60);
        CaminhoManager.addCidade(city14);
        Cidade city15 = new Cidade("Leiria", 20, 40);
        CaminhoManager.addCidade(city15);
        Cidade city16 = new Cidade("Odivelas", 100, 40);
        CaminhoManager.addCidade(city16);
        Cidade city17 = new Cidade("Sines", 200, 40);
        CaminhoManager.addCidade(city17);
        Cidade city18 = new Cidade("Tonela", 200, 20);
        CaminhoManager.addCidade(city18);
        Cidade city19 = new Cidade("Coimbra", 60, 20);
        CaminhoManager.addCidade(city19);
        Cidade city20 = new Cidade("Almada", 160, 20);
        CaminhoManager.addCidade(city20);
        Cidade city21 = new Cidade("Cascais", 150, 55);
        CaminhoManager.addCidade(city21);
        Cidade city22 = new Cidade("Almeirim", 10, 20);
        CaminhoManager.addCidade(city22);
        Cidade city23 = new Cidade("Chaves", 25, 85);
        CaminhoManager.addCidade(city23);
        Cidade city24 = new Cidade("Faro", 185, 35);
        CaminhoManager.addCidade(city24);
        Cidade city25 = new Cidade("Maia", 100, 95);
        CaminhoManager.addCidade(city25);
            //inicializador de cidades aleatorias
//            System.out.println("Cidades Iniciais: ");
//            int indice=0;
//            for (int i = 0; i < (int) Math.sqrt(Integer.parseInt(in.numCidade.getText())); i++) {
//                for (int b = 0; b < (int) Math.sqrt(Integer.parseInt(in.numCidade.getText())); b++) {
//                    indice++;
//                    CaminhoManager.addCidade(new Cidade("", ((Math.random()*100)), ((Math.random()*100))));
//                    System.out.println("Cidade "+(indice)+" x: "+CaminhoManager.getCidade(i).getX()+" y:"+CaminhoManager.getCidade(i).getY());
//                }
//            }

            //Inicializador da População
            Populacao pop = new Populacao(Integer.parseInt(in.populacao.getText()), true);
            System.out.println("Distancia inicial: " + pop.getFittest().getDistancia());

            //Evolui a população por x gerações
            for (int i = 0; i < Integer.parseInt(in.geracao.getText()); i++) {
                System.out.println("Ciclo "+i+" ======================================================\n\n\n");
                pop = new AG(Double.parseDouble(in.txMutacao.getText()), in.elitismo.isSelected()).evoluiPopulacao(pop);
                Painel.setGeracao(i + 1);
                System.out.println("\n\n");
            }

            // Printa o resultado final
            System.out.println("Distância final: " + pop.getFittest().getDistancia());
            System.out.println("Solução:");
            System.out.println(pop.getFittest());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Algum erro ocorreu :( tente novamente");
            e.printStackTrace();
        }
    }

}
