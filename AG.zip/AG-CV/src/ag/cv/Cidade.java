package ag.cv;

public class Cidade {
    private double x;
    private double y;
    private String nome;
    
    //Construtores
    public Cidade(int x, int y){
    	this("Desconhecido", x, y);
    }
    public Cidade(String name, double x, double y){
    	nome = name;
        this.x = x;
        this.y = y;
    }
    
    //Geteres
    public double getX(){
        return x;
    }
    
    public double getY(){
        return y;
    }
    public String getNome(){
    	return nome;
    }
    
    //Metodos
    //Retorna a distancia até uma determinada cidade
    public double distanciaPara(Cidade cidade){
        double xDif = Math.abs(this.x - cidade.x);
        double yDif = Math.abs(this.y - cidade.y);
        double distance = Math.sqrt(Math.pow(xDif, 2) + Math.pow(yDif, 2));
        return distance;
    }
    
    @Override
    public String toString(){
        return ""+nome+"("+x+","+y+")";
    }
}
