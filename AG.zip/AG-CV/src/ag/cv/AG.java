package ag.cv;

public class AG {
    private static double taxaDeMutacao;
    private static int tamanhoDeDisputa;
    private static boolean elitismo;
    private static int mutacoes = 0;

    public AG(double taxaMuta, boolean elitismo) {
        AG.taxaDeMutacao = taxaMuta;
        AG.tamanhoDeDisputa = 15;
        AG.elitismo = elitismo;
    }

    
    

    //Evolui uma população acima de uma geração
    public static Populacao evoluiPopulacao(Populacao pop) {
        Populacao novaPopulacao = new Populacao(pop.tamanhoDaPopulacao(), false);
        
        //Mantem o seu melhor individuo se elitismo estiver ativo
        int elitesAtivas = 0;
        if (elitismo) {
            novaPopulacao.salvarCaminho(0, pop.getFittest());
            elitesAtivas = 1;
        }

        //Crossover a população
        for(int i = elitesAtivas; i < novaPopulacao.tamanhoDaPopulacao(); i++) {
            //Seleciona os pais
            Caminho parente1 = selecaoPorTorneio(pop);
            Caminho parente2 = selecaoPorTorneio(pop);
            //Crossover os pais
            Caminho crianca = crossover(parente1, parente2);
            //Adiciona uma criança a população
            novaPopulacao.salvarCaminho(i, crianca);
        }

        //Muta um pouco a nova população para adicionar um pouco de material genético novo
        mutacoes = 0; //Reseta o numero de mutações
        for(int i = elitesAtivas; i < novaPopulacao.tamanhoDaPopulacao(); i++) {
            mutacao(novaPopulacao.getCaminho(i),i);
        }
        Painel.atualizarJanela(novaPopulacao.getFittest());
        for(int i=0;i<novaPopulacao.tamanhoDaPopulacao();i++)
        {
            System.out.print("Caminho ");
            for(int z=0; z< novaPopulacao.getCaminho(i).tamanhoDoCaminho();z++)
            {
                System.out.print(i+" : "+novaPopulacao.getCaminho(i).getDistancia());
            }
            System.out.println("");
        }
        return novaPopulacao;
    }

    //Aplica o crossover a uma dupla de pais e cria um filho
    public static Caminho crossover(Caminho parente1, Caminho parente2) {
        //Cria um novo filho
        Caminho crianca = new Caminho();

        //Seleciona o inicio e fim - porção do gene - de um sub caminho do parente1
        int posInicial = (int)(Math.random() * parente1.tamanhoDoCaminho());
        int posFinal = (int)(Math.random() * parente1.tamanhoDoCaminho());

        // Adiciona o sub caminho do parente1 no filho
        for (int i = 0; i < crianca.tamanhoDoCaminho(); i++) {
            //se posição inicial é menor que posição final
            if (posInicial < posFinal && i > posInicial && i < posFinal) {
                crianca.setCidade(i, parente1.getCidade(i));
            }//se posição inicial for maior
            else if(posInicial > posFinal) {
                if(!(i < posInicial && i > posFinal)) {
                    crianca.setCidade(i, parente1.getCidade(i));
                }
            }
        }

        //Verificação das cidades restantes através do caminho do parente2
        for (int i = 0; i < parente2.tamanhoDoCaminho(); i++) {
            //Se o filho ainda não possui a cidade na posição i do parente2
            if (!crianca.contemCidade(parente2.getCidade(i))) {
                //Verificação para encontrar um espaço livre no filho
                for (int verificacao = 0; verificacao < crianca.tamanhoDoCaminho(); verificacao++) {
                    //Caso a posição esteja vazia, adiciona a cidade
                    if (crianca.getCidade(verificacao) == null) {
                        crianca.setCidade(verificacao, parente2.getCidade(i));
                        break;
                    }
                }
            }
        }
        return crianca;
    }

    //Muta o caminho atravez de uma mutation swap
    private static void mutacao(Caminho caminho, int i) {
        //Percorre as cidades do caminho
        for(int caminhoPosicao1=0; caminhoPosicao1 < caminho.tamanhoDoCaminho(); caminhoPosicao1++){
            //Randomiza um valor para decidir se á uma mutação ou não
            if(Math.random() < taxaDeMutacao){
            	mutacoes++;
               System.out.println("\n");

                System.out.print("Mutação "+mutacoes+" do caminho "+i+": posição "+caminhoPosicao1+" trocada com a posição ");
                //Pega uma segunda posição no caminho
                int caminhoPosicao2 = (int)(caminho.tamanhoDoCaminho() * Math.random());
                System.out.print(caminhoPosicao2);
                //Pega as cidades alvos do caminho
                Cidade cidade1 = caminho.getCidade(caminhoPosicao1);
                Cidade cidade2 = caminho.getCidade(caminhoPosicao2);
                System.out.println("\n");

                //Swap as cidades alvos
                caminho.setCidade(caminhoPosicao2, cidade1);
                caminho.setCidade(caminhoPosicao1, cidade2);
            }
        }
    }

    //Seleciona os candidatos para o crossover atraves de um torneio
    private static Caminho selecaoPorTorneio(Populacao pop) {
        //Cria uma população torneio
        Populacao torneio = new Populacao(tamanhoDeDisputa, false);
        System.out.print("Torneio ");

        //Para cada lugar no torneio, pegue um candidato aleatorio e adicione-o
        for(int i = 0; i < tamanhoDeDisputa; i++) {
            int randomId = (int)(Math.random() * pop.tamanhoDaPopulacao());
            torneio.salvarCaminho(i, pop.getCaminho(randomId));  
            System.out.print(randomId+"   ");
        }
        System.out.println("");
        //Pega o melhor caminho do torneio e o retorna
        Caminho fittest = torneio.getFittest();
        return fittest;
    }
    
    //Geteres
    public static int getMutações(){
    	return mutacoes;
    }
}
