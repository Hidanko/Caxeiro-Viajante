package ag.cv;

import java.util.ArrayList;
import java.util.Collections;

public class Caminho {
    private ArrayList<Cidade> caminho = new ArrayList<Cidade>(); //Caminho das cidades
    private double fitness = 0;
    private double distancia = 0;
    
    //Construtor
    public Caminho(){
        for (int i = 0; i < CaminhoManager.numeroDeCidades(); i++) {
            caminho.add(null);
        }
    }
    
    public Caminho(ArrayList<Cidade> caminho){
        this.caminho = caminho;
    }

    //Metodos
    //cria um caminho
    public void geracaoIndividual() {
        for(int indiceCidade = 0; indiceCidade < CaminhoManager.numeroDeCidades(); indiceCidade++) {
        	setCidade(indiceCidade, CaminhoManager.getCidade(indiceCidade));
        }
        Collections.shuffle(caminho); //reordena o caminho randômicamente
    }
    
    //Pega a cidade do indice no valor do parâmetro
    public Cidade getCidade(int indice){
        return caminho.get(indice);
    }

    //Define uma cidade em uma determinada posição dentro de um caminho
    public void setCidade(int posicao, Cidade cid) {
        caminho.set(posicao, cid);
        //Quando um caminho muda, o fitness e a distância são zeradas
        fitness = 0;
        distancia = 0;
    }
    
    //Calcula e/ou retorna o fitness do caminho
    public double getFitness(){
        if (fitness == 0) {
        	fitness = 1/(double)getDistancia();
        }
        return fitness;
    }
    
    // Devolve a distancia total do caminho
    public double getDistancia(){
        if (distancia == 0){
            double DistanciaDoCaminho = 0;
            for (int IndiceDaCidade=0; IndiceDaCidade < tamanhoDoCaminho(); IndiceDaCidade++) {
                Cidade daCidade = getCidade(IndiceDaCidade);
                Cidade destino;
                //Verifica se a distancia ja chegou ao limite do caminho,
                //casa ja tenha, adiciona a primeira cidade como próximo destino
                if(IndiceDaCidade+1 < tamanhoDoCaminho()){
                    destino = getCidade(IndiceDaCidade+1);
                }else{
                    destino = getCidade(0);
                }
                // Compara e pega a distancia entre as duas cidades
                DistanciaDoCaminho += daCidade.distanciaPara(destino);
            }
            distancia = DistanciaDoCaminho;
        }
        return distancia;
    }

    // Pega o numero de cidades no caminho
    public int tamanhoDoCaminho() {
        return caminho.size();
    }
    
    // Verifica se o caminho ja possui a cidade
    public boolean contemCidade(Cidade cidade){
        return caminho.contains(cidade);
    }
    
    public boolean equals(Object object){
    	Caminho caminho2;
    	if(object instanceof Caminho){
    		caminho2 = (Caminho) object;
    	}else{
    		return false;
    	}
    	if(tamanhoDoCaminho() == caminho2.tamanhoDoCaminho()){
    		Cidade cidade1, cidade2;
    		for(int IndiceDaCidade = 0; IndiceDaCidade < tamanhoDoCaminho(); IndiceDaCidade++){
                            cidade1 = getCidade(IndiceDaCidade);
    			cidade2 = caminho2.getCidade(IndiceDaCidade);
    			if(!cidade1.equals(cidade2)){
    				return false;
    			}
    		}
    		return true;
    	}
    	return false;
    }
    
    @Override
    public String toString() {
        String geneString = new String();
        for (int i = 0; i < tamanhoDoCaminho(); i++) {
            geneString += getCidade(i)+" -> ";
        }
        return geneString;
    }
}
